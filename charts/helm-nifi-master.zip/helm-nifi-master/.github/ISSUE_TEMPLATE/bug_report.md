---
name: Bug report
about: Create a report to help us improve
title: '[cetic/nifi] issue title'
labels: ''
assignees: ''

---

$${\color{red}This \space project \space is \space not \space maintained \space anymore.}$$

If you are interested in maintaining a fork of this project, please chime in in the [dedicated issue](https://github.com/cetic/helm-nifi/issues/330).
