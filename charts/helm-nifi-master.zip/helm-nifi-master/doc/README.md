Nifi installation & configuration
==========

* [Nifi installation](INSTALLATION.md) - install Nifi locally to update the chart
* [Users management](USERMANAGEMENT.md) - user identification and authorization (Single-User, OIDC, LDAP)
* [Keycloak](Keycloak.md) - example OIDC configuration with Keycloak provider
